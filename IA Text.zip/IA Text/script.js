const body = document.querySelector('body')
const canvas = criarCanvas()
const contexto = canvas.getContext('2d')
body.appendChild(canvas)
const select = {
    x: 0,
    y: 0,
    w: 0,
    h: 0
}
function criarCanvas() {
    const canvas = document.createElement('canvas')
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    canvas.style.position = 'absolute'
    canvas.style.top = 0
    canvas.style.left = 0
    return canvas
}
function criarRect(options) {
    contexto.beginPath()
    contexto.strokeStyle = 'black'
    contexto.rect(options.x, options.y, options.w - options.x, options.h - options.y)
    contexto.stroke()
}
function XY(x, y) {
    select.x = x
    select.y = y
}
function WH(w, h) {
    select.h = h
    select.w = w
}
function draw() {
    criarRect(select)
}
window.onmousedown = function (event) {
    const positionX = event.layerX
    const positionY = event.layerY
    XY(positionX, positionY)
}

window.onmouseup = function (event) {
    const positionX = event.layerX
    const positionY = event.layerY
    WH(positionX, positionY)
    draw()
}

setInterval(() => {
    contexto.clearRect(0, 0, canvas.width, canvas.height)
})